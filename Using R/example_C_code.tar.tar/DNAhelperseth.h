#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include "R_ext/Arith.h"
#include "R_ext/Error.h"
#include "R_ext/Applic.h" /* machar */

#include <string.h>
#include <stdlib.h>

/*------------------------------------------*/
/* R interface                              */
/* reverse all elements of the input string */
/*------------------------------------------*/
SEXP MP_revstring(SEXP x);

