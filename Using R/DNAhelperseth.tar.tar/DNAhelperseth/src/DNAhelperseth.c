#include "DNAhelperseth.h"


static const R_CallMethodDef R_CallDef[] = {
    {"MP_revstring", (DL_FUNC)&MP_revstring, 1},
    {NULL, NULL, 0},
};


void R_init_DNAhelperseth(DllInfo *info)
{
    R_registerRoutines(info, NULL, R_CallDef, NULL, NULL);
}
