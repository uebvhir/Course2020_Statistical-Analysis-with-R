reverseSeq  <- function(seq)
  .Call("MP_revstring", seq, PACKAGE="DNAhelperseth")



