"dnaComplement" <-
function(s) {
    chartr("ATGC", "TACG", s)
}

